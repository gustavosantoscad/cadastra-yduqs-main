"""
Exemplos de uso da API do Google Analytics 4
"""
