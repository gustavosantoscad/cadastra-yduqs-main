# Código de Conduta

Nosso objetivo é criar um ambiente acolhedor e profissional para contribuintes e membros da comunidade.

Regras básicas:
- Seja respeitoso e profissional em todas as interações.
- Não toleramos assédio, discriminação ou comportamento ofensivo.
- Reporte comportamentos inadequados aos mantenedores.

Consequências:
- Violações podem resultar em remoção de permissões de contribuição e notificação dos responsáveis.

Contato para reportar problemas de conduta: maintainers@cadastra.com
